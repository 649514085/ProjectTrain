package cn.techaction.dao;

import cn.techaction.pojo.Addrs;

public interface ActionAddrDao {

	public Addrs findAddrs(Integer addr_id);
}
