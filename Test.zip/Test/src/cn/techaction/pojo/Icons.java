package cn.techaction.pojo;

public class Icons {
	private Integer icons_id;
	private String product_id;
	private String icon_url;
	
	public Integer getIcons_id() {
		return icons_id;
	}
	public void setIcons_id(Integer icons_id) {
		this.icons_id = icons_id;
	}
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
	public String getIcon_url() {
		return icon_url;
	}
	public void setIcon_url(String icon_url) {
		this.icon_url = icon_url;
	}

	
}
