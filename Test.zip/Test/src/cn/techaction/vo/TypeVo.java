package cn.techaction.vo;

public class TypeVo {

	private Integer type_id;
	private Integer rank;
	private Integer gparent_id;
	private Integer parent_id;
	private String type_name;
	public Integer getType_id() {
		return type_id;
	}
	public void setType_id(Integer type_id) {
		this.type_id = type_id;
	}
	public Integer getRank() {
		return rank;
	}
	public void setRank(Integer rank) {
		this.rank = rank;
	}
	public Integer getGparent_id() {
		return gparent_id;
	}
	public void setGparent_id(Integer gparent_id) {
		this.gparent_id = gparent_id;
	}
	public Integer getParent_id() {
		return parent_id;
	}
	public void setParent_id(Integer parent_id) {
		this.parent_id = parent_id;
	}
	public String getType_name() {
		return type_name;
	}
	public void setType_name(String type_name) {
		this.type_name = type_name;
	}
	
	
}
