package cn.techaction.vo;

public class AddrVo {

}
