	function search_label1(){
		if($("#PT1").hasClass("selected")){
			$("#PT1").removeClass("selected");
		}else{
			$("#PT1").addClass("selected");
		}
	}	

	function search_label2(){
		if($("#PT2").hasClass("selected")){
			$("#PT2").removeClass("selected");
		}else{
			$("#PT2").addClass("selected");
		}
	}


	function search_label3(){
		if($("#PT3").hasClass("selected")){
			$("#PT3").removeClass("selected");
		}else{
			$("#PT3").addClass("selected");
		}
	}


	function search_label4(){
		if($("#PT4").hasClass("selected")){
			$("#PT4").removeClass("selected");
		}else{
			$("#PT4").addClass("selected");
		}
	}

	function search_label5(){
		if($("#PT5").hasClass("selected")){
			$("#PT5").removeClass("selected");
		}else{
			$("#PT5").addClass("selected");
		}
	}

	function search_label6(){
		if($("#PT6").hasClass("selected")){
			$("#PT6").removeClass("selected");
		}else{
			$("#PT6").addClass("selected");
		}
	}

	function search_label7(){
		if($("#PT7").hasClass("selected")){
			$("#PT7").removeClass("selected");
		}else{
			$("#PT7").addClass("selected");
		}
	}

	function search_label8(){
		if($("#PT8").hasClass("selected")){
			$("#PT8").removeClass("selected");
		}else{
			$("#PT8").addClass("selected");
		}
	}

	function search_label9(){
		if($("#PT9").hasClass("selected")){
			$("#PT9").removeClass("selected");
		}else{
			$("#PT9").addClass("selected");
		}
	}

	function search_label10(){
		if($("#PT10").hasClass("selected")){
			$("#PT10").removeClass("selected");
		}else{
			$("#PT10").addClass("selected");
		}
	}

	function search_label11(){
		if($("#PS1").hasClass("selected")){
			$("#PS1").removeClass("selected");
		}else{
			$("#PS1").addClass("selected");
		}
	}

	function search_label12(){
		if($("#PS2").hasClass("selected")){
			$("#PS2").removeClass("selected");
		}else{
			$("#PS2").addClass("selected");
		}
	}

	function search_label13(){
		if($("#PS3").hasClass("selected")){
			$("#PS3").removeClass("selected");
		}else{
			$("#PS3").addClass("selected");
		}
	}

	function search_label14(){
		if($("#PS4").hasClass("selected")){
			$("#PS4").removeClass("selected");
		}else{
			$("#PS4").addClass("selected");
		}
	}

	function search_label15(){
		if($("#PS5").hasClass("selected")){
			$("#PS5").removeClass("selected");
		}else{
			$("#PS5").addClass("selected");
		}
	}

	function search_label16(){
		if($("#PS6").hasClass("selected")){
			$("#PS6").removeClass("selected");
		}else{
			$("#PS6").addClass("selected");
		}
	}

	function search_label17(){
		if($("#PS7").hasClass("selected")){
			$("#PS7").removeClass("selected");
		}else{
			$("#PS7").addClass("selected");
		}
	}



	function search_label18(){
		if($("#PS8").hasClass("selected")){
			$("#PS8").removeClass("selected");
		}else{
			$("#PS8").addClass("selected");
		}
	}

	function search_label19(){
		if($("#PS9").hasClass("selected")){
			$("#PS9").removeClass("selected");
		}else{
			$("#PS9").addClass("selected");
		}
	}
	function search_label20(){
		if($("#PS10").hasClass("selected")){
			$("#PS10").removeClass("selected");
		}else{
			$("#PS10").addClass("selected");
		}
	}
	function search_label21(){
		if($("#PS11").hasClass("selected")){
			$("#PS11").removeClass("selected");
		}else{
			$("#PS11").addClass("selected");
		}
	}

	function search_label22(){
		if($("#PS12").hasClass("selected")){
			$("#PS12").removeClass("selected");
		}else{
			$("#PS12").addClass("selected");
		}
	}

	function search_label23(){
		if($("#PS13").hasClass("selected")){
			$("#PS13").removeClass("selected");
		}else{
			$("#PS13").addClass("selected");
		}
	}

	function search_label24(){
		if($("#PS14").hasClass("selected")){
			$("#PS14").removeClass("selected");
		}else{
			$("#PS14").addClass("selected");
		}
	}

	function search_label25(){
		if($("#PS15").hasClass("selected")){
			$("#PS15").removeClass("selected");
		}else{
			$("#PS15").addClass("selected");
		}
	}

	function search_label26(){
		if($("#PS16").hasClass("selected")){
			$("#PS16").removeClass("selected");
		}else{
			$("#PS16").addClass("selected");
		}
	}






























