require.config({
    
});

require(['jquery-1.7.2.min','common','password_back'],function(jquery,common,password_back){
    $(function(){
    });
});